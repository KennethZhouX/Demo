﻿using FXH.DataCenter.WebApi.DataAccess.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FXH.DataCenter.WebApi.Services.User
{
    public class UserService
    {
        public Userinfo GetUserInfo(int id)
        {
            Userinfo user = null;
            using (var context = BaseDatabaseConfig.CreateTestContext())
            {
                user = context.Userinfo.OrderByDescending(u => u.Id).FirstOrDefault();
                Console.WriteLine("New date:" + context.Userinfo.OrderByDescending(u => u.Id).FirstOrDefault());
            }

            return user;
        }
    }
}
