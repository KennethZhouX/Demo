﻿using FXH.DataCenter.WebApi.IServices.Coin;
using FXH.DataCenter.WebApi.Models.Coin;
using FXH.DataCenter.WebApi.Models.Consts;
using FXH.DapperService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dapper;
namespace FXH.DataCenter.WebApi.Services
{
    public class CoinService: ICoinService 
    {
        private readonly DapperRepository _dapperContext;
        public CoinService(DapperRepository dapperContext)
        {
            _dapperContext = dapperContext;
        }

         
        /// <summary>
        /// 读取虚拟币简称别名列表
        /// </summary>
        /// <returns></returns>
        public async   Task<IEnumerable<Coinsymbol_AliasInfo>> GetCoinSymbolAliasListAsync()
        {
            return await  _dapperContext.Connection.QueryAsync<Coinsymbol_AliasInfo>(string.Format(@" select   CoinSymbol,AliasSymbol from {0}  ", TableNameConst.BASE_COINSYMBOL_ALIAS));

        }
    }
}
