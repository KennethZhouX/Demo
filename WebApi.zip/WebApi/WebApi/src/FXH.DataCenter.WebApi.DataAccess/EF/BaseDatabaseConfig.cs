﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace FXH.DataCenter.WebApi.DataAccess.EF
{
    public class BaseDatabaseConfig
    {
        private const string LightConnectionString = "server=localhost;user=root;password=Y+V8h-e9Q.SJ;port=3306;database=test;";

        public static testContext CreateTestContext()
        {
            var optionBuilder = new DbContextOptionsBuilder<testContext>();
            optionBuilder.UseMySql(LightConnectionString);
            var context = new testContext(optionBuilder.Options);
            return context;
        }
    }
}
