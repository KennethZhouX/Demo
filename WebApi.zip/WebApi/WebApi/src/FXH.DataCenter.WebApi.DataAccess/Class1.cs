﻿using System;

namespace FXH.DataCenter.WebApi.DataAccess
{
    public class Class1
    {
    }
}
