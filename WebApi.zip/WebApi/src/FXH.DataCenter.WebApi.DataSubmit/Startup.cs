﻿using System;
using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Cors.Infrastructure;
using FXH.Web.Extensions.Http;
using FXH.RedisService;
using System.Linq;
using FXH.DapperService;
using FXH.Redis.Extensions.Configuration;
using Swashbuckle.AspNetCore.Swagger;

namespace FXH.DataCenter.WebApi.DataSubmit
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
             .SetBasePath(env.ContentRootPath)
             .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
             .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
             .AddEnvironmentVariables(); 

            Configuration = builder.Build();

         
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddResponseCompression();

            #region redis 缓存配置

            RedisConfiguration redisConfiguration;
            if (string.IsNullOrEmpty(Configuration["REDIS_CONNSTR"]))
            {
                redisConfiguration = Configuration.GetSection("Redis").Get<RedisConfiguration>();
            }
            else
            {
                redisConfiguration = new RedisConfiguration { Hosts = Configuration["REDIS_CONNSTR"].Split(',').Select(c => c.Split(':')).Where(c => c.Length == 2).Select(c => new RedisHost { Host = c[0], Port = int.Parse(c[1]) }).ToArray() };
                if (!string.IsNullOrEmpty(Configuration["REDIS_PASSWORD"])) redisConfiguration.Password = Configuration["REDIS_PASSWORD"];
            }
            services.AddRedis(() => redisConfiguration);


            #endregion

            #region 数据库配置
            var connectionString = string.IsNullOrEmpty(Configuration["MYSQL_CONNSTR"]) ? Configuration.GetConnectionString("Connection_DefaultDB") : Configuration["MYSQL_CONNSTR"];
            if (string.IsNullOrEmpty(connectionString) || !connectionString.Contains("server"))
                throw new Exception("ConnectionStrings Lose");
            services.AddDapper(options =>
            {
                options.ConnectionString = connectionString;
                options.DatabaseType = DatabaseType.MySql;
            });
            #endregion

            #region  CORS 跨域设置

            var corsBuilder = new CorsPolicyBuilder();
            corsBuilder.AllowAnyHeader();
            corsBuilder.AllowAnyMethod();
            corsBuilder.AllowAnyOrigin(); // For anyone access.
            //corsBuilder.WithOrigins("http://localhost:56573"); // for a specific url. Don't add a forward slash on the end!
            corsBuilder.AllowCredentials();

            services.AddCors(options =>
            {
                options.AddPolicy("SiteCorsPolicy", corsBuilder.Build());
            });
            string urls = Configuration.GetSection("Cors:urls").Value;
            string[] urlsArray = urls.Split(',');

            services.Add(ServiceDescriptor.Transient<ICorsService, WildcardCorsService>());
            services.Configure<CorsOptions>(options => options.AddPolicy(
                "AllowSameDomain",
                builder => builder.WithOrigins(urlsArray)));
            #endregion


        
            #region Custom service
            services.AddApiService();
            #endregion

            #region Mvc
            services.AddMvc(config =>
            {
                //需要鉴权
                var policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
                config.Filters.Add(new AuthorizeFilter(policy));
            }).AddJsonOptions(options =>
            {
                //jsonx序列化时使用骆驼命名法序列属性
                options.SerializerSettings.ContractResolver
                    = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();
            });
            #endregion

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "My API", Version = "v1" });
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

#if DEBUG
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
            });
#endif
            app.UseCors("SiteCorsPolicy");
            app.UseResponseCompression();



            //针对前端转发
            app.UseForwardedHeaders(new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
            });
            //加入验证
          //  app.UseAuthentication();
            app.UseMvc();
        }
    }
}
