﻿//using FXH.Web.Extensions.Model.Api;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using NSwag.Annotations;

//namespace FXH.DataCenter.WebApi.DataSubmit.Controllers
//{
//    [Route("api/log/userclick/")]
//    public class UserController : Controller
//    {

//        [HttpPost("id")]
//        [AllowAnonymous]
//        [SwaggerResponse(ApiResponseCode.OK, typeof(SucessDetail), Description = "操作成功")]
//        [SwaggerResponse(ApiResponseCode.ERROR, typeof(ErrorDetail), Description = "操作失败，详情见返回对象")]
//        public void GetUserInfo(int userId)
//        {
//            UserService service = new UserService();
//            service.GetUserInfo(userId);
//        }
//    }
//}
