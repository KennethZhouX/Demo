﻿using FXH.DataCenter.WebApi.IServices.Coin;
using FXH.DataCenter.WebApi.Models.NoPassedCoin;
using FXH.Web.Extensions.Model.Api;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NSwag.Annotations;

namespace FXH.DataCenter.WebApi.DataSubmit.Controllers
{
    [Route("api/coin")]
    public class NoPassedCoinController : Controller
    {
        private INoPassedCoinService _coinService;

        public NoPassedCoinController(INoPassedCoinService coinService)
        {
            _coinService = coinService;
        }


        [HttpPost("add")]
        [AllowAnonymous]
        [SwaggerResponse(ApiResponseCode.OK, typeof(SucessDetail), Description = "操作成功")]
        [SwaggerResponse(ApiResponseCode.ERROR, typeof(ErrorDetail), Description = "操作失败，详情见返回对象")]
        public IActionResult AddNoPassedCoin([FromBody] NoPassedCoinRequest coinRequest)
        {
            if (string.IsNullOrEmpty(coinRequest.CoinCode))
            {
                return BadRequest("虚拟币Code不能为空");
            }
            _coinService.AddNopassedCoin(coinRequest);
            return Ok();
        }
    }
}
