﻿using FXH.DataCenter.WebApi.DataSubmit.Models.Const;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FXH.DataCenter.WebApi.DataSubmit.Models
{
    /// <summary>
    /// 用户点击日志表
    /// </summary>
    [Table(TableNameConst.USER_CLICKMODEL)]
    public class User_ClickModel
    {
        #region 属性

        /// <summary>自增</summary>
        [DisplayName("自增")]
        [Key]
        public Int64 LogID { get; set; }

        /// <summary>默认为0	用户ID</summary>
        [DisplayName("默认为0	用户ID")]

        public Int32 UserID { get; set; }

        /// <summary>浏览器客户端cookie 存放的区分唯一标记的uid 或是app的uid</summary>
        [DisplayName("浏览器客户端cookie存放的区分唯一标记的uid或是app的uid")]

        public String UID { get; set; }

        /// <summary>user agent</summary>
        [DisplayName("useragent")]
        public String UserAgent { get; set; }
        /// <summary>Refer的url链接</summary>
        [DisplayName("Refer的url链接")]
        public String Referer { get; set; }

     
        /// <summary>点击的url链接</summary>
        [DisplayName("点击的url链接")]
        public String TargetUrl { get; set; }

        [DisplayName("点击的域名")]
        public String Domain { get; set; }

        

        /// <summary>用户的ip地址</summary>
        [DisplayName("用户的ip地址")]

        public String IP { get; set; }

        /// <summary>日志时间</summary>
        [DisplayName("日志时间")]

        public DateTime LogTime { get; set; }

        /// <summary>应用id</summary>
        [DisplayName("应用id")] 
        public Int16 AppID { get; set; }

        /// <summary>操作系统类型（字符串表示，如：windows 10,android）</summary>
        [DisplayName("操作系统类型字符串表示，如：windows10,android")]

        public String OsType { get; set; }

        /// <summary>浏览器类型</summary>
        [DisplayName("浏览器类型")] 
        public String BrowserType { get; set; }

        /// <summary>应用的版本号</summary>
        [DisplayName("应用的版本号")] 
        public String AppVer { get; set; }

        #endregion
    }
}
