﻿using System;
using FXH.DataCenter.WebApi.Models.DataCenterContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FXH.DataCenter.WebApi.Models.DataContext
{
    public partial class DataCenterContext : DbContext
    {
        public DataCenterContext()
        {
        }

        public DataCenterContext(DbContextOptions<DataCenterContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BaseCoin> BaseCoin { get; set; }
        public virtual DbSet<BaseCoinLang> BaseCoinLang { get; set; }
        public virtual DbSet<BaseCoinNopassed> BaseCoinNopassed { get; set; }
        public virtual DbSet<BaseCoinNopassedLang> BaseCoinNopassedLang { get; set; }
        public virtual DbSet<BaseCoinTag> BaseCoinTag { get; set; }
        public virtual DbSet<BaseCointag1> BaseCointag1 { get; set; }
        public virtual DbSet<BaseExchange> BaseExchange { get; set; }
        public virtual DbSet<BaseExchangeLang> BaseExchangeLang { get; set; }
        public virtual DbSet<BaseExchangeNopassed> BaseExchangeNopassed { get; set; }
        public virtual DbSet<BaseExchangeNopassedLang> BaseExchangeNopassedLang { get; set; }
        public virtual DbSet<BaseExchangeTag> BaseExchangeTag { get; set; }
        public virtual DbSet<BaseExchangetag1> BaseExchangetag1 { get; set; }
        public virtual DbSet<BaseExchangeWallet> BaseExchangeWallet { get; set; }
        public virtual DbSet<BaseIco> BaseIco { get; set; }
        public virtual DbSet<ConfigCountry> ConfigCountry { get; set; }
        public virtual DbSet<ConfigCountryLang> ConfigCountryLang { get; set; }
        public virtual DbSet<ConfigCurrencyRate> ConfigCurrencyRate { get; set; }
        public virtual DbSet<ConfigExchangeSpecialcoin> ConfigExchangeSpecialcoin { get; set; }
        public virtual DbSet<ConfigLanguage> ConfigLanguage { get; set; }
        public virtual DbSet<Demo> Demo { get; set; }
        public virtual DbSet<Itemp> Itemp { get; set; }
        public virtual DbSet<MarketTicker> MarketTicker { get; set; }
        public virtual DbSet<Member> Member { get; set; }
        public virtual DbSet<SysFunction> SysFunction { get; set; }
        public virtual DbSet<SysMenu> SysMenu { get; set; }
        public virtual DbSet<SysMenufunction> SysMenufunction { get; set; }
        public virtual DbSet<SysNumber> SysNumber { get; set; }
        public virtual DbSet<SysRole> SysRole { get; set; }
        public virtual DbSet<SysRolemenufunction> SysRolemenufunction { get; set; }
        public virtual DbSet<SysUser> SysUser { get; set; }
        public virtual DbSet<SysUserrole> SysUserrole { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("Server=192.168.1.66;Database=datacenter;User ID=datacenter;Password=AzdTG2X10AQY0L3xf6gNLy0XeURAFwKQxNboIyF6;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BaseCoin>(entity =>
            {
                entity.HasKey(e => e.CoinCode);

                entity.ToTable("base_coin");

                entity.Property(e => e.CoinCode)
                    .HasColumnType("varchar(255)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.Algorithm).HasColumnType("varchar(255)");

                entity.Property(e => e.BlockChainLink).HasColumnType("varchar(255)");

                entity.Property(e => e.CodeLink).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIcon).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconBig).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconMid).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconWebp).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinName)
                    .IsRequired()
                    .HasColumnType("varchar(63)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CoinStatus).HasColumnType("tinyint(4)");

                entity.Property(e => e.CoinSymbol)
                    .IsRequired()
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.CoinType).HasColumnType("tinyint(4)");

                entity.Property(e => e.ContractAddress).HasColumnType("varchar(255)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ExchangePlatNum).HasColumnType("int(11)");

                entity.Property(e => e.IsMineable).HasColumnType("bit(1)");

                entity.Property(e => e.IsRank).HasColumnType("bit(1)");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.OnlineTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.OtherLinks).HasColumnType("varchar(2047)");

                entity.Property(e => e.ProofType).HasColumnType("varchar(255)");

                entity.Property(e => e.RankNo).HasColumnType("int(11)");

                entity.Property(e => e.SiteLink).HasColumnType("varchar(255)");

                entity.Property(e => e.TokenPlatForm).HasColumnType("varchar(255)");

                entity.Property(e => e.UniqueCode)
                    .HasColumnType("varchar(31)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Wallets).HasColumnType("varchar(511)");

                entity.Property(e => e.WhitePaperLink).HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<BaseCoinLang>(entity =>
            {
                entity.HasKey(e => new { e.CoinCode, e.LanguageCode });

                entity.ToTable("base_coin_lang");

                entity.Property(e => e.CoinCode).HasColumnType("varchar(255)");

                entity.Property(e => e.LanguageCode).HasColumnType("varchar(31)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CoinInfoStatus).HasColumnType("tinyint(4)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.Description).HasColumnType("text");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ModifyTime).HasColumnType("timestamp");

                entity.Property(e => e.NativeName).HasColumnType("varchar(63)");

                entity.Property(e => e.TeamDesc).HasColumnType("text");
            });

            modelBuilder.Entity<BaseCoinNopassed>(entity =>
            {
                entity.ToTable("base_coin_nopassed");

                entity.HasIndex(e => e.CoinCode)
                    .HasName("coincode");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.Algorithm).HasColumnType("varchar(255)");

                entity.Property(e => e.BlockChainLink).HasColumnType("varchar(255)");

                entity.Property(e => e.CirculatingSupply).HasColumnType("bigint(20)");

                entity.Property(e => e.CodeLink).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinCode)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconBig).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconMid).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconSmall).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconUrl).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinIconWebpMid).HasColumnType("varchar(255)");

                entity.Property(e => e.CoinName)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.CoinSource)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CoinSymbol)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ContractAddress).HasColumnType("varchar(255)");

                entity.Property(e => e.CreateTime).HasColumnType("datetime");

                entity.Property(e => e.CreatorSource).HasColumnType("varchar(255)");

                entity.Property(e => e.CrowdfundingPrice).HasColumnType("decimal(10,0)");

                entity.Property(e => e.CrowdfundingPriceUnit).HasColumnType("varchar(15)");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangePlatNum).HasColumnType("int(11)");

                entity.Property(e => e.IsIfo)
                    .HasColumnName("IsIFO")
                    .HasColumnType("bit(1)");

                entity.Property(e => e.IsMineable).HasColumnType("bit(1)");

                entity.Property(e => e.IsToken).HasColumnType("bit(1)");

                entity.Property(e => e.IssuePrice)
                    .HasColumnType("decimal(31,15)")
                    .HasDefaultValueSql("'0.000000000000000'");

                entity.Property(e => e.IssuePriceUnit).HasColumnType("varchar(255)");

                entity.Property(e => e.IssuePriceUsd)
                    .HasColumnType("decimal(31,6)")
                    .HasDefaultValueSql("'0.000000'");

                entity.Property(e => e.IssueTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.MaxSupply).HasColumnType("bigint(20)");

                entity.Property(e => e.ModifyTime).HasColumnType("datetime");

                entity.Property(e => e.OnlineTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'0001-01-01 00:00:00'");

                entity.Property(e => e.OtherLinks).HasColumnType("text");

                entity.Property(e => e.PayRemark).HasColumnType("varchar(255)");

                entity.Property(e => e.ProofType).HasColumnType("varchar(255)");

                entity.Property(e => e.RandomReceiptNumber)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ReceiptNumber)
                    .IsRequired()
                    .HasColumnType("varchar(255)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Remark).HasColumnType("varchar(255)");

                entity.Property(e => e.ReviewStatus).HasColumnType("int(11)");

                entity.Property(e => e.SiteLink).HasColumnType("varchar(255)");

                entity.Property(e => e.SubmitterEmail).HasColumnType("varchar(255)");

                entity.Property(e => e.SubmitterName).HasColumnType("varchar(255)");

                entity.Property(e => e.SubmitterTelegram).HasColumnType("varchar(255)");

                entity.Property(e => e.TokenPlatForm).HasColumnType("varchar(255)");

                entity.Property(e => e.WhitePaperLink).HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<BaseCoinNopassedLang>(entity =>
            {
                entity.ToTable("base_coin_nopassed_lang");

                entity.HasIndex(e => new { e.LangCode, e.NopassedCoinId })
                    .HasName("coinid_lang_unique")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CoinCode)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.CoinDescription).HasColumnType("text");

                entity.Property(e => e.CoinNativeName).HasColumnType("varchar(255)");

                entity.Property(e => e.CreateTime).HasColumnType("datetime");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.LangCode)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.LinksJson).HasColumnType("text");

                entity.Property(e => e.ModifyTime).HasColumnType("datetime");

                entity.Property(e => e.NopassedCoinId).HasColumnType("int(11)");
            });

            modelBuilder.Entity<BaseCoinTag>(entity =>
            {
                entity.HasKey(e => new { e.CoinCode, e.TagCode });

                entity.ToTable("base_coin_tag");

                entity.Property(e => e.CoinCode).HasColumnType("varchar(31)");

                entity.Property(e => e.TagCode).HasColumnType("varchar(31)");
            });

            modelBuilder.Entity<BaseCointag1>(entity =>
            {
                entity.HasKey(e => e.TagCode);

                entity.ToTable("base_cointag");

                entity.Property(e => e.TagCode).HasColumnType("varchar(31)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("timestamp");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("timestamp");

                entity.Property(e => e.OrderNo).HasColumnType("smallint(6)");

                entity.Property(e => e.TagName)
                    .IsRequired()
                    .HasColumnType("varchar(31)");
            });

            modelBuilder.Entity<BaseExchange>(entity =>
            {
                entity.HasKey(e => e.ExchangeCode);

                entity.ToTable("base_exchange");

                entity.Property(e => e.ExchangeCode).HasColumnType("varchar(255)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CountryCode)
                    .IsRequired()
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ExchangeIcon).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconBig).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconMid).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconWebp).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeName)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeStar).HasColumnType("int(11)");

                entity.Property(e => e.ExchangeStatus).HasColumnType("tinyint(4)");

                entity.Property(e => e.ExchangeUrls)
                    .IsRequired()
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.IsInnovation).HasColumnType("bit(1)");

                entity.Property(e => e.IsNoTradingFees).HasColumnType("bit(1)");

                entity.Property(e => e.IsRank).HasColumnType("bit(1)");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.OtherLinks).HasColumnType("varchar(255)");

                entity.Property(e => e.PlatformTokenCode).HasColumnType("varchar(31)");

                entity.Property(e => e.PlatformTokenName).HasColumnType("varchar(63)");

                entity.Property(e => e.RankNo).HasColumnType("int(11)");
            });

            modelBuilder.Entity<BaseExchangeLang>(entity =>
            {
                entity.HasKey(e => new { e.ExchangeCode, e.LanguageCode });

                entity.ToTable("base_exchange_lang");

                entity.Property(e => e.ExchangeCode).HasColumnType("varchar(255)");

                entity.Property(e => e.LanguageCode).HasColumnType("varchar(31)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.Description).HasColumnType("text");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.NativeName)
                    .IsRequired()
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.Summary)
                    .IsRequired()
                    .HasColumnType("varchar(511)");
            });

            modelBuilder.Entity<BaseExchangeNopassed>(entity =>
            {
                entity.ToTable("base_exchange_nopassed");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ApiUrl)
                    .IsRequired()
                    .HasColumnType("text");

                entity.Property(e => e.CountryCode)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'")
                    .ValueGeneratedOnAddOrUpdate();

                entity.Property(e => e.CreatorSource).HasColumnType("varchar(255)");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ExchangeCode)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconBig).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconMid).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconSmall).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconUrl)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeIconWebpMid).HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeName)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeStar).HasColumnType("int(11)");

                entity.Property(e => e.ExchangeUrl)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.IsNoTradingFees).HasColumnType("bit(1)");

                entity.Property(e => e.IsTradingAsMining).HasColumnType("bit(1)");

                entity.Property(e => e.LaunchDate)
                    .HasColumnType("timestamp");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("timestamp");

                entity.Property(e => e.OtherLinks).HasColumnType("varchar(2047)");

                entity.Property(e => e.PayRemark).HasColumnType("varchar(255)");

                entity.Property(e => e.PlatformTokenCode).HasColumnType("varchar(31)");

                entity.Property(e => e.PlatformTokenName).HasColumnType("varchar(255)");

                entity.Property(e => e.ProvideMining)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.RandomReceiptNumber).HasColumnType("int(11)");

                entity.Property(e => e.ReceiptNumber).HasColumnType("varchar(255)");

                entity.Property(e => e.Remark)
                    .HasColumnType("varchar(255)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.ReviewStatus).HasColumnType("int(11)");

                entity.Property(e => e.SubmitterEmail)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.SubmitterName)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.SubmitterTelegram).HasColumnType("varchar(255)");

                entity.Property(e => e.SupportExchangeTypes).HasColumnType("int(11)");
            });

            modelBuilder.Entity<BaseExchangeNopassedLang>(entity =>
            {
                entity.HasKey(e => e.D);

                entity.ToTable("base_exchange_nopassed_lang");

                entity.Property(e => e.D).HasColumnType("int(11)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("timestamp");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ExchangeCode)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeDecription)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ExchangeNativeName)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.LangCode)
                    .IsRequired()
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.LinksJson).HasColumnType("varchar(255)");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("timestamp");

                entity.Property(e => e.NopassedExchangeId).HasColumnType("int(11)");
            });

            modelBuilder.Entity<BaseExchangeTag>(entity =>
            {
                entity.HasKey(e => new { e.ExchangeCode, e.TagCode });

                entity.ToTable("base_exchange_tag");

                entity.Property(e => e.ExchangeCode).HasColumnType("varchar(31)");

                entity.Property(e => e.TagCode).HasColumnType("varchar(31)");
            });

            modelBuilder.Entity<BaseExchangetag1>(entity =>
            {
                entity.HasKey(e => e.TagCode);

                entity.ToTable("base_exchangetag");

                entity.Property(e => e.TagCode).HasColumnType("varchar(31)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("datetime");

                entity.Property(e => e.OrderNo).HasColumnType("smallint(6)");

                entity.Property(e => e.TagName)
                    .IsRequired()
                    .HasColumnType("varchar(31)");
            });

            modelBuilder.Entity<BaseExchangeWallet>(entity =>
            {
                entity.ToTable("base_exchange_wallet");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CoinCode)
                    .IsRequired()
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.ExchangeCode)
                    .IsRequired()
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.WalletAddr)
                    .IsRequired()
                    .HasColumnType("varchar(63)");
            });

            modelBuilder.Entity<BaseIco>(entity =>
            {
                entity.HasKey(e => e.CoinCode);

                entity.ToTable("base_ico");

                entity.Property(e => e.CoinCode).HasColumnType("varchar(31)");

                entity.Property(e => e.AveragePrice)
                    .HasColumnName("Average_Price")
                    .HasColumnType("decimal(20,8)");

                entity.Property(e => e.AveragePriceCny)
                    .HasColumnName("Average_Price_Cny")
                    .HasColumnType("decimal(20,8)");

                entity.Property(e => e.EndDate)
                    .HasColumnName("End_Date")
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.Features).HasColumnType("varchar(255)");

                entity.Property(e => e.FundingCap)
                    .HasColumnName("Funding_Cap")
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.FundingTarget)
                    .HasColumnName("Funding_Target")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.FundsRaisedCny)
                    .HasColumnName("Funds_Raised_Cny")
                    .HasColumnType("decimal(20,0)");

                entity.Property(e => e.FundsRaisedList)
                    .HasColumnName("Funds_Raised_List")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.FundsRaisedUsd)
                    .HasColumnName("Funds_Raised_Usd")
                    .HasColumnType("decimal(20,0)");

                entity.Property(e => e.Jurisdiction).HasColumnType("varchar(63)");

                entity.Property(e => e.LegalAdvisers)
                    .HasColumnName("Legal_Advisers")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.LegalForm)
                    .HasColumnName("Legal_Form")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.PaymentMethod)
                    .HasColumnName("Payment_Method")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.PublicPortfolio)
                    .HasColumnName("Public_Portfolio")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.SaleWebsite)
                    .HasColumnName("Sale_Website")
                    .HasColumnType("varchar(127)");

                entity.Property(e => e.SecurityAudit)
                    .HasColumnName("Security_Audit")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.StartDate)
                    .HasColumnName("Start_Date")
                    .HasColumnType("timestamp")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.StartPrice)
                    .HasColumnName("Start_Price")
                    .HasColumnType("decimal(20,8)");

                entity.Property(e => e.StartPriceCurrency).HasColumnType("varchar(31)");

                entity.Property(e => e.Status).HasColumnType("varchar(31)");

                entity.Property(e => e.TokenPercentageForInvestors)
                    .HasColumnName("Token_Percentage_For_Investors")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.TokenPlatForm)
                    .HasColumnName("Token_PlatForm")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.TokenReserveSplit)
                    .HasColumnName("Token_Reserve_Split")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.TokenSupplyPostSale)
                    .HasColumnName("Token_Supply_Post_Sale")
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.TotalTokensSupply).HasColumnName("Total_Tokens_Supply");
            });

            modelBuilder.Entity<ConfigCountry>(entity =>
            {
                entity.HasKey(e => e.CountryCode);

                entity.ToTable("config_country");

                entity.Property(e => e.CountryCode).HasColumnType("varchar(255)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Alpha2).HasColumnType("varchar(255)");

                entity.Property(e => e.Alpha3)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.CountryName)
                    .HasColumnType("varchar(255)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CreateTime).HasColumnType("datetime");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ModifyTime).HasColumnType("datetime");

                entity.Property(e => e.NativeName)
                    .HasColumnType("varchar(255)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Number)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.Remark)
                    .IsRequired()
                    .HasColumnType("varchar(255)")
                    .HasDefaultValueSql("''");
            });

            modelBuilder.Entity<ConfigCountryLang>(entity =>
            {
                entity.ToTable("config_country_lang");

                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CountryCode)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.CreateTime).HasColumnType("datetime");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.LanguageCode)
                    .IsRequired()
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.ModifyTime).HasColumnType("datetime");

                entity.Property(e => e.NativeName)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.Remark).HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<ConfigCurrencyRate>(entity =>
            {
                entity.HasKey(e => e.ExchangeCurrency);

                entity.ToTable("config_currency_rate");

                entity.Property(e => e.ExchangeCurrency)
                    .HasColumnName("Exchange_Currency")
                    .HasColumnType("varchar(20)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.BaseCurrency)
                    .IsRequired()
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.ExchangeRate)
                    .HasColumnName("Exchange_Rate")
                    .HasColumnType("decimal(30,15)")
                    .HasDefaultValueSql("'0.000000000000000'");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.OrderNo)
                    .HasColumnType("smallint(6)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.RateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<ConfigExchangeSpecialcoin>(entity =>
            {
                entity.ToTable("config_exchange_specialcoin");

                entity.HasIndex(e => new { e.BaseSymbol, e.ExchangeSymbol, e.ExchangeCode })
                    .HasName("indx_exchangesymbole")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.BaseSymbol)
                    .IsRequired()
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.CreateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.ExchangeCode)
                    .IsRequired()
                    .HasColumnType("varchar(30)");

                entity.Property(e => e.ExchangeRate)
                    .HasColumnType("decimal(10,2)")
                    .HasDefaultValueSql("'1.00'");

                entity.Property(e => e.ExchangeSymbol)
                    .IsRequired()
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.ModifyTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("'CURRENT_TIMESTAMP'");
            });

            modelBuilder.Entity<ConfigLanguage>(entity =>
            {
                entity.HasKey(e => e.LanguageCode);

                entity.ToTable("config_language");

                entity.Property(e => e.LanguageCode).HasColumnType("varchar(31)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AliasName)
                    .IsRequired()
                    .HasColumnType("varchar(31)");

                entity.Property(e => e.CreateTime).HasColumnType("datetime");

                entity.Property(e => e.DefaultCurrency)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Enabled).HasColumnType("bit(1)");

                entity.Property(e => e.FlagUri)
                    .IsRequired()
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.ModifyTime).HasColumnType("datetime");

                entity.Property(e => e.NativeName)
                    .IsRequired()
                    .HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<Demo>(entity =>
            {
                entity.HasKey(e => e.TagCode);

                entity.ToTable("demo");

                entity.Property(e => e.TagCode).HasColumnType("varchar(31)");

                entity.Property(e => e.AddOprId)
                    .HasColumnName("AddOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.CreateTime).HasColumnType("datetime");

                entity.Property(e => e.EditOprId)
                    .HasColumnName("EditOprID")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.ModifyTime).HasColumnType("datetime");

                entity.Property(e => e.OrderNo).HasColumnType("smallint(6)");

                entity.Property(e => e.TagName)
                    .IsRequired()
                    .HasColumnType("varchar(31)");
            });

            modelBuilder.Entity<Itemp>(entity =>
            {
                entity.HasKey(e => new { e.Id1, e.Id2 });

                entity.ToTable("itemp");

                entity.Property(e => e.Id1)
                    .HasColumnName("id1")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Id2)
                    .HasColumnName("id2")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Data)
                    .IsRequired()
                    .HasColumnName("data")
                    .HasColumnType("varchar(30)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Def)
                    .IsRequired()
                    .HasColumnName("def")
                    .HasColumnType("varchar(30)")
                    .HasDefaultValueSql("'sss'");
            });

            modelBuilder.Entity<MarketTicker>(entity =>
            {
                entity.HasKey(e => new { e.SymbolPair, e.ExchangeCode });

                entity.ToTable("market_ticker");

                entity.Property(e => e.SymbolPair).HasColumnType("varchar(25)");

                entity.Property(e => e.ExchangeCode)
                    .HasColumnType("varchar(30)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Buy)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.Change)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.CoinCode)
                    .IsRequired()
                    .HasColumnType("varchar(30)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CoinCodePair)
                    .IsRequired()
                    .HasColumnName("CoinCode_Pair")
                    .HasColumnType("varchar(30)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.ExchangeUrl)
                    .IsRequired()
                    .HasColumnType("varchar(200)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.HasKline)
                    .IsRequired()
                    .HasColumnName("HasKLine")
                    .HasColumnType("bit(1)")
                    .HasDefaultValueSql("'b\\'0\\''");

                entity.Property(e => e.High)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.HoldAmount)
                    .HasColumnName("Hold_Amount")
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.IsExcludeVol)
                    .IsRequired()
                    .HasColumnType("bit(1)")
                    .HasDefaultValueSql("'b\\'0\\''");

                entity.Property(e => e.IsFutures)
                    .IsRequired()
                    .HasColumnType("bit(1)")
                    .HasDefaultValueSql("'b\\'0\\''");

                entity.Property(e => e.Last)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.Low)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.Open)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.Pair1)
                    .IsRequired()
                    .HasColumnType("varchar(20)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Pair2)
                    .IsRequired()
                    .HasColumnType("varchar(20)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.PercentChange)
                    .HasColumnType("decimal(12,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PriceBtc)
                    .HasColumnName("Price_Btc")
                    .HasColumnType("decimal(30,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.PriceBtcPair)
                    .HasColumnName("Price_Btc_Pair")
                    .HasColumnType("decimal(30,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.PriceCny)
                    .HasColumnName("Price_Cny")
                    .HasColumnType("decimal(30,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.PriceCnyPair)
                    .HasColumnName("Price_Cny_Pair")
                    .HasColumnType("decimal(30,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.PriceDiffRatio)
                    .HasColumnName("Price_DiffRatio")
                    .HasColumnType("decimal(30,2)");

                entity.Property(e => e.PriceUsd)
                    .HasColumnName("Price_Usd")
                    .HasColumnType("decimal(30,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.PriceUsdPair)
                    .HasColumnName("Price_Usd_Pair")
                    .HasColumnType("decimal(30,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.Sell)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.TickerStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.TickerTime).HasColumnType("datetime");

                entity.Property(e => e.TickerType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.TradeType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.UnitAmount)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.UpdateTime).HasColumnType("datetime");

                entity.Property(e => e.Vol)
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.VolumeBtc)
                    .HasColumnName("Volume_Btc")
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.VolumeCny)
                    .HasColumnName("Volume_Cny")
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");

                entity.Property(e => e.VolumePercent)
                    .HasColumnName("Volume_Percent")
                    .HasColumnType("decimal(10,2)")
                    .HasDefaultValueSql("'0.00'");

                entity.Property(e => e.VolumePercentExchange)
                    .HasColumnName("Volume_Percent_Exchange")
                    .HasColumnType("decimal(10,2)")
                    .HasDefaultValueSql("'0.00'");

                entity.Property(e => e.VolumePercentPair)
                    .HasColumnName("Volume_Percent_Pair")
                    .HasColumnType("decimal(10,2)")
                    .HasDefaultValueSql("'0.00'");

                entity.Property(e => e.VolumePercentWeighted)
                    .HasColumnName("Volume_Percent_Weighted")
                    .HasColumnType("decimal(10,3)")
                    .HasDefaultValueSql("'0.000'");

                entity.Property(e => e.VolumeUsd)
                    .HasColumnName("Volume_Usd")
                    .HasColumnType("decimal(50,20)")
                    .HasDefaultValueSql("'0.00000000000000000000'");
            });

            modelBuilder.Entity<Member>(entity =>
            {
                entity.ToTable("member");

                entity.Property(e => e.MemberId)
                    .HasColumnName("Member_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.MemberBirthday)
                    .HasColumnName("Member_Birthday")
                    .HasColumnType("datetime");

                entity.Property(e => e.MemberCreateTime)
                    .HasColumnName("Member_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.MemberFilePath)
                    .HasColumnName("Member_FilePath")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.MemberIntroduce)
                    .HasColumnName("Member_Introduce")
                    .HasColumnType("text");

                entity.Property(e => e.MemberName)
                    .HasColumnName("Member_Name")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.MemberNum)
                    .HasColumnName("Member_Num")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.MemberPhone)
                    .HasColumnName("Member_Phone")
                    .HasColumnType("int(11)");

                entity.Property(e => e.MemberPhoto)
                    .HasColumnName("Member_Photo")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.MemberSex)
                    .HasColumnName("Member_Sex")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.MemberUserId)
                    .HasColumnName("Member_UserID")
                    .HasColumnType("varchar(511)");
            });

            modelBuilder.Entity<SysFunction>(entity =>
            {
                entity.HasKey(e => e.FunctionId);

                entity.ToTable("sys_function");

                entity.Property(e => e.FunctionId)
                    .HasColumnName("Function_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.FunctionByName)
                    .HasColumnName("Function_ByName")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.FunctionCreateTime)
                    .HasColumnName("Function_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.FunctionName)
                    .HasColumnName("Function_Name")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.FunctionNum)
                    .HasColumnName("Function_Num")
                    .HasColumnType("varchar(63)");
            });

            modelBuilder.Entity<SysMenu>(entity =>
            {
                entity.HasKey(e => e.MenuId);

                entity.ToTable("sys_menu");

                entity.Property(e => e.MenuId)
                    .HasColumnName("Menu_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.MenuCreateTime)
                    .HasColumnName("Menu_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.MenuIcon)
                    .HasColumnName("Menu_Icon")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.MenuName)
                    .HasColumnName("Menu_Name")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.MenuNum)
                    .HasColumnName("Menu_Num")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.MenuParentId)
                    .HasColumnName("Menu_ParentID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.MenuUrl)
                    .HasColumnName("Menu_Url")
                    .HasColumnType("varchar(63)");
            });

            modelBuilder.Entity<SysMenufunction>(entity =>
            {
                entity.HasKey(e => e.MenuFunctionId);

                entity.ToTable("sys_menufunction");

                entity.Property(e => e.MenuFunctionId)
                    .HasColumnName("MenuFunction_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.MenuFunctionCreateTime)
                    .HasColumnName("MenuFunction_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.MenuFunctionFunctionId)
                    .HasColumnName("MenuFunction_FunctionID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.MenuFunctionMenuId)
                    .HasColumnName("MenuFunction_MenuID")
                    .HasColumnType("varchar(511)");
            });

            modelBuilder.Entity<SysNumber>(entity =>
            {
                entity.HasKey(e => e.NumberId);

                entity.ToTable("sys_number");

                entity.Property(e => e.NumberId)
                    .HasColumnName("Number_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.NumberCreateTime)
                    .HasColumnName("Number_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.NumberDataBase)
                    .HasColumnName("Number_DataBase")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.NumberNum)
                    .HasColumnName("Number_Num")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.NumberNumField)
                    .HasColumnName("Number_NumField")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.NumberTableName)
                    .HasColumnName("Number_TableName")
                    .HasColumnType("varchar(63)");
            });

            modelBuilder.Entity<SysRole>(entity =>
            {
                entity.HasKey(e => e.RoleId);

                entity.ToTable("sys_role");

                entity.Property(e => e.RoleId)
                    .HasColumnName("Role_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.RoleCreateTime)
                    .HasColumnName("Role_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.RoleIsDelete)
                    .HasColumnName("Role_IsDelete")
                    .HasColumnType("int(11)");

                entity.Property(e => e.RoleName)
                    .HasColumnName("Role_Name")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.RoleNum)
                    .HasColumnName("Role_Num")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.RoleRemark)
                    .HasColumnName("Role_Remark")
                    .HasColumnType("varchar(63)");
            });

            modelBuilder.Entity<SysRolemenufunction>(entity =>
            {
                entity.HasKey(e => e.RoleMenuFunctionId);

                entity.ToTable("sys_rolemenufunction");

                entity.Property(e => e.RoleMenuFunctionId)
                    .HasColumnName("RoleMenuFunction_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.RoleMenuFunctionCreateTime)
                    .HasColumnName("RoleMenuFunction_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.RoleMenuFunctionFunctionId)
                    .HasColumnName("RoleMenuFunction_FunctionID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.RoleMenuFunctionMenuId)
                    .HasColumnName("RoleMenuFunction_MenuID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.RoleMenuFunctionRoleId)
                    .HasColumnName("RoleMenuFunction_RoleID")
                    .HasColumnType("varchar(511)");
            });

            modelBuilder.Entity<SysUser>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("sys_user");

                entity.Property(e => e.UserId)
                    .HasColumnName("User_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.UserCreateTime)
                    .HasColumnName("User_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.UserEmail)
                    .HasColumnName("User_Email")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.UserIsDelete)
                    .HasColumnName("User_IsDelete")
                    .HasColumnType("int(11)");

                entity.Property(e => e.UserLoginName)
                    .HasColumnName("User_LoginName")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.UserName)
                    .HasColumnName("User_Name")
                    .HasColumnType("varchar(63)");

                entity.Property(e => e.UserPwd)
                    .HasColumnName("User_Pwd")
                    .HasColumnType("varchar(127)");
            });

            modelBuilder.Entity<SysUserrole>(entity =>
            {
                entity.HasKey(e => e.UserRoleId);

                entity.ToTable("sys_userrole");

                entity.Property(e => e.UserRoleId)
                    .HasColumnName("UserRole_ID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.UserRoleCreateTime)
                    .HasColumnName("UserRole_CreateTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.UserRoleRoleId)
                    .HasColumnName("UserRole_RoleID")
                    .HasColumnType("varchar(511)");

                entity.Property(e => e.UserRoleUserId)
                    .HasColumnName("UserRole_UserID")
                    .HasColumnType("varchar(511)");
            });
        }
    }
}
