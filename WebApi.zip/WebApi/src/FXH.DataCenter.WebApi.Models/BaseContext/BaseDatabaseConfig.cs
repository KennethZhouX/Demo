﻿using Microsoft.EntityFrameworkCore;

namespace FXH.DataCenter.WebApi.Models.DataContext
{
    public class BaseDatabaseConfig
    {
        private const string DataCenterConnectionString = "Server=192.168.1.66;Database=datacenter;User ID=datacenter;Password=AzdTG2X10AQY0L3xf6gNLy0XeURAFwKQxNboIyF6;";

        public static DataCenterContext CreateDataCenterContext()
        {
            var optionBuilder = new DbContextOptionsBuilder<DataCenterContext>();
            optionBuilder.UseMySql(DataCenterConnectionString);
            var context = new DataCenterContext(optionBuilder.Options);
            return context;
        }
    }
}
