﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FXH.DataCenter.WebApi.Models.NoPassedExchangeExtension
{
    class NoPassedExchangeLangModel
    {
    }
}
