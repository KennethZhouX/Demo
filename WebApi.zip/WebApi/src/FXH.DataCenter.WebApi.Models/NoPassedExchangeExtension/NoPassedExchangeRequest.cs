﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FXH.DataCenter.WebApi.Models.NoPassedExchangeExtension
{
    public class NoPassedExchangeRequest
    {
        public string ExchangeCode { get; set; }
        public string ExchangeName { get; set; }
        public string PlatformTokenCode { get; set; }
        public string PlatformTokenName { get; set; }
        public string ExchangeUrl { get; set; }
        public string ExchangeIcoUrl { get; set; }
        public int ExchangeStar { get; set; }
        public int SupportExchangeTypes { get; set; }
        public DateTime LaunchDate { get; set; }
        public string CountryCode { get; set; }
        public bool IsTradingAsMining { get; set; }
        public string ProvideMining { get; set; }
        public bool IsNoTradingFees { get; set; }
        public string ApiUrl { get; set; }
        public string OtherLinks { get; set; }
        public string SubmitterName { get; set; }
        public string SubmitterEmail { get; set; }
        public string SubmitterTelegram { get; set; }
        public string PayMark { get; set; }
        public string ReceiptNumber { get; set; }
        public int RandomReceiptNumber { get; set; }
        public string Remark { get; set; }
        public string CreatorSource { get; set; }
    }
}
