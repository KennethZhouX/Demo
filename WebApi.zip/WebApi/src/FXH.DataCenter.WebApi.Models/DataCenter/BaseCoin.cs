﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseCoin
    {
        public string CoinCode { get; set; }
        public string UniqueCode { get; set; }
        public string CoinName { get; set; }
        public string CoinSymbol { get; set; }
        public string CoinIcon { get; set; }
        public string CoinIconMid { get; set; }
        public string CoinIconWebp { get; set; }
        public string CoinIconBig { get; set; }
        public double CirculatingSupply { get; set; }
        public double MaxSupply { get; set; }
        public double TotalSupply { get; set; }
        public string TokenPlatForm { get; set; }
        public DateTime OnlineTime { get; set; }
        public bool IsMineable { get; set; }
        public sbyte CoinType { get; set; }
        public sbyte CoinStatus { get; set; }
        public bool IsRank { get; set; }
        public int RankNo { get; set; }
        public int ExchangePlatNum { get; set; }
        public string SiteLink { get; set; }
        public string BlockChainLink { get; set; }
        public string WhitePaperLink { get; set; }
        public string CodeLink { get; set; }
        public string ContractAddress { get; set; }
        public string OtherLinks { get; set; }
        public string ProofType { get; set; }
        public string Algorithm { get; set; }
        public string Wallets { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
