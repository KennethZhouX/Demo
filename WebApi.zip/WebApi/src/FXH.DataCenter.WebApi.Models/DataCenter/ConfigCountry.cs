﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class ConfigCountry
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string NativeName { get; set; }
        public int Number { get; set; }
        public string Alpha2 { get; set; }
        public string Alpha3 { get; set; }
        public string Remark { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime ModifyTime { get; set; }
        public int? AddOprId { get; set; }
        public int? EditOprId { get; set; }
    }
}
