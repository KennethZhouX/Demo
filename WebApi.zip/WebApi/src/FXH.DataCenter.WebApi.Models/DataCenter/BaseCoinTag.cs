﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseCoinTag
    {
        public string CoinCode { get; set; }
        public string TagCode { get; set; }
    }
}
