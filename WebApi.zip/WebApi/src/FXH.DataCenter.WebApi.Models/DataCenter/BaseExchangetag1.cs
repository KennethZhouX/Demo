﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseExchangetag1
    {
        public string TagCode { get; set; }
        public string TagName { get; set; }
        public short? OrderNo { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
