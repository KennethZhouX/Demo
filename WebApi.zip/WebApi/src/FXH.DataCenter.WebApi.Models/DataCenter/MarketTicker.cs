﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class MarketTicker
    {
        public string SymbolPair { get; set; }
        public string ExchangeCode { get; set; }
        public string CoinCode { get; set; }
        public string CoinCodePair { get; set; }
        public string ExchangeUrl { get; set; }
        public string Pair1 { get; set; }
        public string Pair2 { get; set; }
        public decimal Open { get; set; }
        public decimal Buy { get; set; }
        public decimal Sell { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Last { get; set; }
        public decimal Vol { get; set; }
        public decimal UnitAmount { get; set; }
        public decimal HoldAmount { get; set; }
        public decimal PercentChange { get; set; }
        public decimal Change { get; set; }
        public decimal VolumeCny { get; set; }
        public decimal VolumeUsd { get; set; }
        public decimal VolumeBtc { get; set; }
        public decimal VolumePercent { get; set; }
        public decimal VolumePercentWeighted { get; set; }
        public decimal VolumePercentPair { get; set; }
        public decimal VolumePercentExchange { get; set; }
        public decimal PriceCny { get; set; }
        public decimal PriceUsd { get; set; }
        public decimal PriceBtc { get; set; }
        public decimal PriceCnyPair { get; set; }
        public decimal PriceUsdPair { get; set; }
        public decimal PriceBtcPair { get; set; }
        public sbyte TickerStatus { get; set; }
        public sbyte TickerType { get; set; }
        public sbyte TradeType { get; set; }
        public bool? IsFutures { get; set; }
        public bool? IsExcludeVol { get; set; }
        public bool? HasKline { get; set; }
        public decimal PriceDiffRatio { get; set; }
        public DateTime TickerTime { get; set; }
        public DateTime UpdateTime { get; set; }
    }
}
