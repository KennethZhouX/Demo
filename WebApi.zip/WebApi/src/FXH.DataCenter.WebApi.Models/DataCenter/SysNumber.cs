﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class SysNumber
    {
        public string NumberId { get; set; }
        public string NumberNum { get; set; }
        public string NumberDataBase { get; set; }
        public string NumberTableName { get; set; }
        public string NumberNumField { get; set; }
        public DateTime? NumberCreateTime { get; set; }
    }
}
