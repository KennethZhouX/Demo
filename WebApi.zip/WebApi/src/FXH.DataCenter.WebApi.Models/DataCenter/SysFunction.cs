﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class SysFunction
    {
        public string FunctionId { get; set; }
        public string FunctionNum { get; set; }
        public string FunctionName { get; set; }
        public string FunctionByName { get; set; }
        public DateTime? FunctionCreateTime { get; set; }
    }
}
