﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class SysMenufunction
    {
        public string MenuFunctionId { get; set; }
        public string MenuFunctionMenuId { get; set; }
        public string MenuFunctionFunctionId { get; set; }
        public DateTime? MenuFunctionCreateTime { get; set; }
    }
}
