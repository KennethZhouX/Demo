﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseCoinNopassed
    {
        public int Id { get; set; }
        public string CoinCode { get; set; }
        public string CoinName { get; set; }
        public string CoinSymbol { get; set; }
        public string CoinIconUrl { get; set; }
        public string CoinIconSmall { get; set; }
        public string CoinIconMid { get; set; }
        public string CoinIconWebpMid { get; set; }
        public string CoinIconBig { get; set; }
        public DateTime IssueTime { get; set; }
        public decimal IssuePrice { get; set; }
        public string IssuePriceUnit { get; set; }
        public decimal? CrowdfundingPrice { get; set; }
        public string CrowdfundingPriceUnit { get; set; }
        public long MaxSupply { get; set; }
        public long CirculatingSupply { get; set; }
        public string TokenPlatForm { get; set; }
        public string BlockChainLink { get; set; }
        public string WhitePaperLink { get; set; }
        public string ContractAddress { get; set; }
        public string SiteLink { get; set; }
        public bool IsMineable { get; set; }
        public bool IsIfo { get; set; }
        public string OtherLinks { get; set; }
        public string CodeLink { get; set; }
        public string Remark { get; set; }
        public int ReviewStatus { get; set; }
        public string SubmitterName { get; set; }
        public string SubmitterEmail { get; set; }
        public string SubmitterTelegram { get; set; }
        public string CreatorSource { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
        public int? ExchangePlatNum { get; set; }
        public bool? IsToken { get; set; }
        public DateTime? OnlineTime { get; set; }
        public decimal? IssuePriceUsd { get; set; }
        public string ReceiptNumber { get; set; }
        public string PayRemark { get; set; }
        public int? RandomReceiptNumber { get; set; }
        public int? CoinSource { get; set; }
        public string ProofType { get; set; }
        public string Algorithm { get; set; }
    }
}
