﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class SysRole
    {
        public string RoleId { get; set; }
        public string RoleNum { get; set; }
        public string RoleName { get; set; }
        public string RoleRemark { get; set; }
        public int? RoleIsDelete { get; set; }
        public DateTime? RoleCreateTime { get; set; }
    }
}
