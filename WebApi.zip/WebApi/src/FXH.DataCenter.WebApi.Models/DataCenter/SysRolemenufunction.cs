﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class SysRolemenufunction
    {
        public string RoleMenuFunctionId { get; set; }
        public string RoleMenuFunctionRoleId { get; set; }
        public string RoleMenuFunctionFunctionId { get; set; }
        public string RoleMenuFunctionMenuId { get; set; }
        public DateTime? RoleMenuFunctionCreateTime { get; set; }
    }
}
