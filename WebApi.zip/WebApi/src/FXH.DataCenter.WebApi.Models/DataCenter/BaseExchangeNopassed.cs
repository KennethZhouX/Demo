﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseExchangeNopassed
    {
        public int Id { get; set; }
        public string ExchangeCode { get; set; }
        public string ExchangeName { get; set; }
        public string PlatformTokenCode { get; set; }
        public string PlatformTokenName { get; set; }
        public string ExchangeUrl { get; set; }
        public string ExchangeIconUrl { get; set; }
        public string ExchangeIconSmall { get; set; }
        public string ExchangeIconMid { get; set; }
        public string ExchangeIconBig { get; set; }
        public string ExchangeIconWebpMid { get; set; }
        public int? ExchangeStar { get; set; }
        public int SupportExchangeTypes { get; set; }
        public DateTime LaunchDate { get; set; }
        public string CountryCode { get; set; }
        public bool IsTradingAsMining { get; set; }
        public string ProvideMining { get; set; }
        public bool? IsNoTradingFees { get; set; }
        public string ApiUrl { get; set; }
        public string OtherLinks { get; set; }
        public string SubmitterName { get; set; }
        public string SubmitterEmail { get; set; }
        public string SubmitterTelegram { get; set; }
        public string PayRemark { get; set; }
        public string ReceiptNumber { get; set; }
        public int? RandomReceiptNumber { get; set; }
        public string Remark { get; set; }
        public int ReviewStatus { get; set; }
        public string CreatorSource { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
