﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class Itemp
    {
        public int Id1 { get; set; }
        public int Id2 { get; set; }
        public string Data { get; set; }
        public string Def { get; set; }
    }
}
