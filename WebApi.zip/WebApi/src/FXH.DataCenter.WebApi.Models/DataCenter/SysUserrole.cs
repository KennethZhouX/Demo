﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class SysUserrole
    {
        public string UserRoleId { get; set; }
        public string UserRoleUserId { get; set; }
        public string UserRoleRoleId { get; set; }
        public DateTime? UserRoleCreateTime { get; set; }
    }
}
