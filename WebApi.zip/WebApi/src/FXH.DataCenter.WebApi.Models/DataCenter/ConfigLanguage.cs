﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class ConfigLanguage
    {
        public string LanguageCode { get; set; }
        public string AliasName { get; set; }
        public string NativeName { get; set; }
        public string FlagUri { get; set; }
        public byte[] MoBlob { get; set; }
        public byte[] PoBlob { get; set; }
        public bool Enabled { get; set; }
        public string DefaultCurrency { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public int? AddOprId { get; set; }
        public int? EditOprId { get; set; }
    }
}
