﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseExchangeTag
    {
        public string ExchangeCode { get; set; }
        public string TagCode { get; set; }
    }
}
