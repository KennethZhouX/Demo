﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseExchangeLang
    {
        public string ExchangeCode { get; set; }
        public string LanguageCode { get; set; }
        public string NativeName { get; set; }
        public string Summary { get; set; }
        public string Description { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
