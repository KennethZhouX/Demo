﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class Member
    {
        public string MemberId { get; set; }
        public string MemberNum { get; set; }
        public string MemberName { get; set; }
        public int? MemberPhone { get; set; }
        public string MemberSex { get; set; }
        public DateTime? MemberBirthday { get; set; }
        public string MemberPhoto { get; set; }
        public string MemberUserId { get; set; }
        public string MemberIntroduce { get; set; }
        public string MemberFilePath { get; set; }
        public DateTime? MemberCreateTime { get; set; }
    }
}
