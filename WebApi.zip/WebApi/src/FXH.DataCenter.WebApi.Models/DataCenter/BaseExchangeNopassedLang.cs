﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseExchangeNopassedLang
    {
        public int D { get; set; }
        public int NopassedExchangeId { get; set; }
        public string ExchangeCode { get; set; }
        public string LangCode { get; set; }
        public string ExchangeNativeName { get; set; }
        public string ExchangeDecription { get; set; }
        public string LinksJson { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
