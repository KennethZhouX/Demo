﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseCoinNopassedLang
    {
        public int Id { get; set; }
        public int NopassedCoinId { get; set; }
        public string CoinCode { get; set; }
        public string CoinNativeName { get; set; }
        public string CoinDescription { get; set; }
        public string LinksJson { get; set; }
        public string LangCode { get; set; }
        public DateTime? CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
