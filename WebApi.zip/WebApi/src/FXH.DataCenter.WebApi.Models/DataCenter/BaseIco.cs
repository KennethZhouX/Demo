﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseIco
    {
        public string CoinCode { get; set; }
        public string Status { get; set; }
        public string TokenPlatForm { get; set; }
        public string PublicPortfolio { get; set; }
        public string TokenReserveSplit { get; set; }
        public string TokenPercentageForInvestors { get; set; }
        public double? TotalTokensSupply { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string TokenSupplyPostSale { get; set; }
        public decimal? StartPrice { get; set; }
        public string StartPriceCurrency { get; set; }
        public string FundingTarget { get; set; }
        public string FundingCap { get; set; }
        public decimal? AveragePrice { get; set; }
        public decimal? AveragePriceCny { get; set; }
        public string FundsRaisedList { get; set; }
        public decimal? FundsRaisedUsd { get; set; }
        public decimal? FundsRaisedCny { get; set; }
        public string PaymentMethod { get; set; }
        public string Features { get; set; }
        public string SecurityAudit { get; set; }
        public string LegalForm { get; set; }
        public string Jurisdiction { get; set; }
        public string LegalAdvisers { get; set; }
        public string SaleWebsite { get; set; }
    }
}
