﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class ConfigExchangeSpecialcoin
    {
        public int Id { get; set; }
        public string BaseSymbol { get; set; }
        public string ExchangeSymbol { get; set; }
        public string ExchangeCode { get; set; }
        public decimal? ExchangeRate { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
