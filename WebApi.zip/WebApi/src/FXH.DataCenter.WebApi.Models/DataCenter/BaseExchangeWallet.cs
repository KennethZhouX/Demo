﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseExchangeWallet
    {
        public int Id { get; set; }
        public string ExchangeCode { get; set; }
        public string CoinCode { get; set; }
        public string WalletAddr { get; set; }
    }
}
