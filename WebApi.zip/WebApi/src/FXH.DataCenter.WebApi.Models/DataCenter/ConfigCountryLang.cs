﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class ConfigCountryLang
    {
        public int Id { get; set; }
        public string CountryCode { get; set; }
        public string NativeName { get; set; }
        public string LanguageCode { get; set; }
        public string Remark { get; set; }
        public DateTime? CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public int? AddOprId { get; set; }
        public int? EditOprId { get; set; }
    }
}
