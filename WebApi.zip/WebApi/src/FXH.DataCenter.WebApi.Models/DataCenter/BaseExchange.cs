﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class BaseExchange
    {
        public string ExchangeCode { get; set; }
        public string ExchangeName { get; set; }
        public string PlatformTokenCode { get; set; }
        public string PlatformTokenName { get; set; }
        public string ExchangeUrls { get; set; }
        public string ExchangeIcon { get; set; }
        public string ExchangeIconMid { get; set; }
        public int ExchangeStar { get; set; }
        public string CountryCode { get; set; }
        public bool IsNoTradingFees { get; set; }
        public sbyte ExchangeStatus { get; set; }
        public bool IsRank { get; set; }
        public bool? IsInnovation { get; set; }
        public int RankNo { get; set; }
        public string OtherLinks { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
        public string ExchangeIconWebp { get; set; }
        public string ExchangeIconBig { get; set; }
    }
}
