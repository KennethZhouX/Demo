﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class ConfigCurrencyRate
    {
        public DateTime? RateTime { get; set; }
        public string BaseCurrency { get; set; }
        public string ExchangeCurrency { get; set; }
        public decimal? ExchangeRate { get; set; }
        public short? OrderNo { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime ModifyTime { get; set; }
        public string AddOprId { get; set; }
        public string EditOprId { get; set; }
    }
}
