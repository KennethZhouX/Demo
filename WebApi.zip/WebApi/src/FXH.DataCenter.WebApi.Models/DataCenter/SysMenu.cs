﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.DataCenterContext
{
    public partial class SysMenu
    {
        public string MenuId { get; set; }
        public string MenuNum { get; set; }
        public string MenuName { get; set; }
        public string MenuUrl { get; set; }
        public string MenuIcon { get; set; }
        public string MenuParentId { get; set; }
        public DateTime? MenuCreateTime { get; set; }
    }
}
