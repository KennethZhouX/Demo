﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FXH.DataCenter.WebApi.Models.Coin
{

    /// <summary>虚拟币别名</summary>
    [Serializable]
    [Description("虚拟币别名")]
    public class Coinsymbol_AliasInfo
    {
        
        #region 属性

        /// <summary>虚拟币简称</summary> 
        public String CoinSymbol { get; set; }

        /// <summary>fxh对应的真正的虚拟币简称</summary> 

        public String AliasSymbol { get; set; } 

        #endregion


    }
}
