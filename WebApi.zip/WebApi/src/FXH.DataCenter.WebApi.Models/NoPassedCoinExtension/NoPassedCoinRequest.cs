﻿using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Models.NoPassedCoin
{
    public class NoPassedCoinRequest
    {
        //虚拟币名称（英文）
        public string CoinName { get; set; }
        public string CoinCode { get; set; }
        public string CoinSymbol { get; set; }
        public string CoinIconUrl { get; set; }
        public int CoinSource { get; set; }
        public DateTime IssueTime { get; set; }
        public int IssuePrice { get; set; }
        public string IssuPriceUnit { get; set; }
        public int IssuePriceUsd { get; set; }
        public int CrowdfundingPrice { get; set; }
        public string CrowdfundingPriceUnit { get; set; }
        public int ExchangePlatNum { get; set; }
        public int MaxSupply { get; set; }
        public int CirculatingSupply { get; set; }
        public string TokenPlatform { get; set; }
        public string ContractAddress { get; set; }
        public string WhitePaperLink { get; set; }
        public string BlockChainLink { get; set; }
        public string SiteLink { get; set; }
        public bool IsMineable { get; set; }
        public bool IsIFO { get; set; }
        public bool IsToken { get; set; }
        public DateTime OnlioneTime { get; set; }
        public string CodeLink { get; set; }
        public string ContactName { get; set; }
        //public string TelegramGroup { get; set; }
        //public string Facebook { get; set; }
        //public string Medium { get; set; }
        //public string Reddit { get; set; }
        //public string Twitter { get; set; }
        public string OtherLinks { get; set; }
        public string ContactMail { get; set; }
        public string PayReamrk { get; set; }
        public string Wechat { get; set; }
        public string ProofType { get; set; }
        public string ReceiptNumber { get; set; }
        public int RandomReceiptNumber { get; set; }
        public string Algorithm { get; set; }
        public List<NoPassedCoinLangModel> NoPassedCoinLangModels { get; set; }
    }
}
