﻿namespace FXH.DataCenter.WebApi.Models.NoPassedCoin
{
    public class NoPassedCoinLangModel
    {
        public string LangCode { get; set; }
        public string CoinNativeName { get; set; }
        public string DescriptionNative { get; set; }
    }
}
