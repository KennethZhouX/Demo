﻿using FXH.DataCenter.WebApi.Models.DataCenterContext;
using FXH.DataCenter.WebApi.Models.NoPassedCoin;
using System;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Services.Coin
{
    public static class NoPassedCoinExtension
    {
        public static void UpdateNoPassedCoin(this BaseCoinNopassed baseCoinNopassed, NoPassedCoinRequest request)
        {
            baseCoinNopassed.CoinCode = request.CoinCode;
            baseCoinNopassed.CoinName = request.CoinName;
            baseCoinNopassed.CoinSymbol = request.CoinSymbol;
            baseCoinNopassed.CoinIconUrl = request.CoinIconUrl;
            baseCoinNopassed.BlockChainLink = request.BlockChainLink;
            baseCoinNopassed.WhitePaperLink = request.WhitePaperLink;
            baseCoinNopassed.MaxSupply = request.MaxSupply;
            baseCoinNopassed.CirculatingSupply = request.CirculatingSupply;
            baseCoinNopassed.ContractAddress = request.ContractAddress;
            baseCoinNopassed.CoinSource = request.CoinSource;
            baseCoinNopassed.IssueTime = request.IssueTime;
            baseCoinNopassed.IssuePrice = request.IssuePrice;
            baseCoinNopassed.IssuePriceUnit = request.IssuPriceUnit;
            baseCoinNopassed.IssuePriceUsd = request.IssuePriceUsd;
            baseCoinNopassed.CrowdfundingPrice = request.CrowdfundingPrice;
            baseCoinNopassed.CrowdfundingPriceUnit = request.CrowdfundingPriceUnit;
            baseCoinNopassed.ExchangePlatNum = request.ExchangePlatNum;
            baseCoinNopassed.CodeLink = request.CodeLink;
            baseCoinNopassed.SiteLink = request.SiteLink;
            baseCoinNopassed.IsIfo = request.IsIFO;
            baseCoinNopassed.IsMineable = request.IsMineable;
            baseCoinNopassed.OtherLinks = request.OtherLinks;
            baseCoinNopassed.IsToken = request.IsToken;
            baseCoinNopassed.PayRemark = request.PayReamrk;
            baseCoinNopassed.ReviewStatus = 0;
            baseCoinNopassed.AddOprId = string.Empty;
            baseCoinNopassed.EditOprId = string.Empty;
            baseCoinNopassed.CreateTime = DateTime.Now;
            baseCoinNopassed.OnlineTime = request.OnlioneTime;
            baseCoinNopassed.CreatorSource = string.Empty;
            baseCoinNopassed.ProofType = request.ProofType;
            baseCoinNopassed.ReceiptNumber = request.ReceiptNumber;
            baseCoinNopassed.RandomReceiptNumber = request.RandomReceiptNumber;
            baseCoinNopassed.SubmitterName = request.ContactName;
            baseCoinNopassed.SubmitterEmail = string.Empty;
            baseCoinNopassed.TokenPlatForm = request.TokenPlatform;
            baseCoinNopassed.Algorithm = request.Algorithm;
        }

        public static Dictionary<string, string> LanguageType()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("CN", "zh-CN");
            dic.Add("US", "en-US");
            return dic;
        }
    }
}
