﻿using System.Collections.Generic;
using FXH.DataCenter.WebApi.IServices.Coin;
using FXH.DataCenter.WebApi.Models.DataCenterContext;
using FXH.DataCenter.WebApi.Models.DataContext;

namespace FXH.DataCenter.WebApi.Services.Coin
{
    public class NoPassedCoinLangService : INoPassedCoinLangService
    {
        /// <summary>
        /// 添加未审核Coin多语言
        /// </summary>
        /// <param name="coinNopassedLangs"></param>
        public void AddNoPassedCoinLangs(List<BaseCoinNopassedLang> coinNopassedLangs)
        {
            using (var context = BaseDatabaseConfig.CreateDataCenterContext())
            {
                context.AddRange(coinNopassedLangs);
                context.SaveChanges();
            }
        }
    }
}
