﻿using Dapper;
using FXH.DapperService;
using FXH.DataCenter.WebApi.IServices.Coin;
using FXH.DataCenter.WebApi.Models.Coin;
using FXH.DataCenter.WebApi.Models.Consts;
using FXH.DataCenter.WebApi.Models.DataCenterContext;
using FXH.DataCenter.WebApi.Models.DataContext;
using FXH.DataCenter.WebApi.Models.NoPassedCoin;
using FXH.DataCenter.WebApi.Services.Coin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FXH.DataCenter.WebApi.Services
{
    public class NoPassedCoinService: INoPassedCoinService 
    {
        private readonly DapperRepository _dapperContext;
        private readonly INoPassedCoinLangService _coinLangService;

        public NoPassedCoinService(
            DapperRepository dapperContext,
            INoPassedCoinLangService coinLangService
            )
        {
            _coinLangService = coinLangService;
            _dapperContext = dapperContext;
        }

        /// <summary>
        /// 读取虚拟币简称别名列表
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Coinsymbol_AliasInfo>> GetCoinSymbolAliasListAsync()
        {
            return await _dapperContext.Connection.QueryAsync<Coinsymbol_AliasInfo>(string.Format(@" select   CoinSymbol,AliasSymbol from {0}  ", TableNameConst.BASE_COINSYMBOL_ALIAS));

        }

        /// <summary>
        /// 添加未审核虚拟币
        /// </summary>
        /// <param name="baseCoinNopassed"></param>
        public void AddNopassedCoin(NoPassedCoinRequest request)
        {
            var baseCoinNoPassed = ConvertToBaseCoinNopassedM(request);

            using (var context = BaseDatabaseConfig.CreateDataCenterContext())
            {
                var baseCoin = context.BaseCoin.FirstOrDefault(coin => coin.CoinCode == baseCoinNoPassed.CoinCode);
                var existBaseCoinNopasseds = context.BaseCoinNopassed.FirstOrDefault(coin => coin.CoinCode == baseCoinNoPassed.CoinCode); 

                if (baseCoin != null)
                {
                    baseCoinNoPassed.ReviewStatus = -1;
                }

                if (existBaseCoinNopasseds != null)
                {
                    existBaseCoinNopasseds.UpdateNoPassedCoin(request);
                }
                else
                {
                    context.BaseCoinNopassed.Add(baseCoinNoPassed);
                }
                
                context.SaveChanges();

                var baseCoinNopassedLangList = GetBaseCoinNopassedLangList(baseCoinNoPassed.Id, request);
                _coinLangService.AddNoPassedCoinLangs(baseCoinNopassedLangList);
            }


        }

        /// <summary>
        /// 转换BaseCoinNopassed Model
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private BaseCoinNopassed ConvertToBaseCoinNopassedM(NoPassedCoinRequest request)
        {
            return new BaseCoinNopassed
            {
                CoinCode = request.CoinCode,
                CoinName = request.CoinName,
                CoinSymbol = request.CoinSymbol,
                CoinIconUrl = request.CoinIconUrl,
                BlockChainLink = request.BlockChainLink,
                WhitePaperLink = request.WhitePaperLink,
                MaxSupply = request.MaxSupply,
                CirculatingSupply = request.CirculatingSupply,
                ContractAddress = request.ContractAddress,
                CoinSource = request.CoinSource,
                IssueTime = request.IssueTime,
                IssuePrice = request.IssuePrice,
                IssuePriceUnit = request.IssuPriceUnit,
                IssuePriceUsd = request.IssuePriceUsd,
                CrowdfundingPrice = request.CrowdfundingPrice,
                CrowdfundingPriceUnit = request.CrowdfundingPriceUnit,
                ExchangePlatNum = request.ExchangePlatNum,
                CodeLink = request.CodeLink,
                SiteLink = request.SiteLink,
                IsIfo = request.IsIFO,
                IsMineable = request.IsMineable,
                OtherLinks = request.OtherLinks,
                IsToken = request.IsToken,
                PayRemark = request.PayReamrk,
                ReviewStatus = 0,
                AddOprId = string.Empty,
                EditOprId = string.Empty,
                CreateTime = DateTime.Now,
                OnlineTime = request.OnlioneTime,
                CreatorSource = string.Empty,
                ProofType = request.ProofType,
                ReceiptNumber = request.ReceiptNumber,
                RandomReceiptNumber = request.RandomReceiptNumber,
                SubmitterName = request.ContactName,
                SubmitterEmail = string.Empty,
                TokenPlatForm = request.TokenPlatform,
                Algorithm = request.Algorithm
            };
        }

        /// <summary>
        /// 添加未审核虚拟币多语言
        /// </summary>
        /// <param name="noPassedCoinId"></param>
        /// <param name="request"></param>
        private List<BaseCoinNopassedLang> GetBaseCoinNopassedLangList(int noPassedCoinId, NoPassedCoinRequest request)
        {
            var baseCoinNopassedLangList = new List<BaseCoinNopassedLang>();

            request.NoPassedCoinLangModels.ForEach(coin =>
            {
                baseCoinNopassedLangList.Add(new BaseCoinNopassedLang
                {
                    CoinCode = request.CoinCode,
                    NopassedCoinId = noPassedCoinId,
                    CoinNativeName = coin.CoinNativeName,
                    LangCode = coin.LangCode,
                    CoinDescription = coin.DescriptionNative,
                    AddOprId = string.Empty
                     
                });
            });

            return baseCoinNopassedLangList;
        }
    }
}
