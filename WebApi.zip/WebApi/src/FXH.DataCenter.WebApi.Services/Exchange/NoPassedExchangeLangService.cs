﻿using FXH.DataCenter.WebApi.IServices.Exchange;
using FXH.DataCenter.WebApi.Models.DataCenterContext;
using FXH.DataCenter.WebApi.Models.DataContext;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.Services.Exchange
{
    public class NoPassedExchangeLangService : INoPassedExchangeLangService
    {
        /// <summary>
        /// 添加未审核Coin多语言
        /// </summary>
        /// <param name="coinNopassedLangs"></param>
        public void AddNoPassedCoinLangs(List<BaseCoinNopassedLang> coinNopassedLangs)
        {
            using (var context = BaseDatabaseConfig.CreateDataCenterContext())
            {
                context.AddRange(coinNopassedLangs);
                context.SaveChanges();
            }
        }
    }
}
