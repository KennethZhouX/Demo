﻿using FXH.DataCenter.WebApi.Models.DataCenterContext;
using System.Collections.Generic;

namespace FXH.DataCenter.WebApi.IServices.Coin
{
    public interface INoPassedCoinLangService
    {
        void AddNoPassedCoinLangs(List<BaseCoinNopassedLang> coinNopassedLangs);
    }
}
