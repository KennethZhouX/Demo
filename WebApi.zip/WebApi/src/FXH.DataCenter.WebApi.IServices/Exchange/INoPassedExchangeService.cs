﻿using FXH.DataCenter.WebApi.Models.Coin;
using FXH.DataCenter.WebApi.Models.NoPassedCoin;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FXH.DataCenter.WebApi.IServices.Exchange
{
    public interface INoPassedExchangeService
    {
        /// <summary>
        /// 读取虚拟币简称别名列表
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<Coinsymbol_AliasInfo>> GetCoinSymbolAliasListAsync();

        /// <summary>
        /// 添加未审核虚拟币
        /// </summary>
        /// <param name="coinRequetModel"></param>
        void AddNopassedCoin(NoPassedCoinRequest coinRequetModel);

    }
}
